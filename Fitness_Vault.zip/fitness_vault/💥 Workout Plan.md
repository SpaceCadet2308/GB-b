---
tags: [workout-plan, reference]
---

# 💥 THE TRAINING GRIMOIRE ── Workout Plan

> [!quote] **"The strongest is the one who enjoys training."** — Yujiro Hanma
>
> **Goal:** Wide back. Round shoulders. Full chest. Tapered waist.
> **Format:** 4 lifting days + 2 cardio days + 1 rest per week.

---

## 🗓️ THE WEEKLY SPLIT

| Day | Session | Theme |
|---|---|---|
| **MON** | 🔴 **PUSH** | Chest + Shoulders + Triceps |
| **TUE** | 🔵 **PULL** | Back + Biceps + Rear Delts |
| **WED** | 🟢 **LEGS + CORE** | Quads + Hams + Calves + Abs |
| **THU** | ❤️ **LISS Cardio** | 30–45 min walk / bike |
| **FRI** | 🟡 **UPPER AESTHETIC** | Full upper, pump-focused |
| **SAT** | ❤️ **Cardio + Abs** | 30 min cardio + core |
| **SUN** | 😴 **Rest** | Walk, stretch, recover |

---

## 🔴 DAY 1 — PUSH // "The Chest-Crushing Strike"

> **Mantra:** *"Mount Fuji wasn't built flat."* — Build the upper chest shelf.
> **Rest:** 60–90s between sets. 2 min after heavy compounds.

| # | Exercise | Sets | Reps | Tempo | Cue |
|---|---|---|---|---|---|
| 1 | Incline DB Press | 4 | 8–10 | 3-1-1 | Lead with chest, elbows ~45° |
| 2 | Flat DB Press | 3 | 8–10 | 3-1-1 | Full stretch at bottom |
| 3 | Machine Chest Press | 3 | 10–12 | 2-1-2 | Squeeze HARD |
| 4 | Seated DB Shoulder Press | 4 | 8–10 | 2-1-1 | No lockout at top |
| 5 | Lateral Raises | 4 | 12–15 | 2-0-2 | Lead with elbows |
| 6 | Cable Tricep Pushdown | 3 | 12–15 | 2-1-2 | Elbows glued to sides |
| 7 | Overhead DB Tricep Ext | 3 | 10–12 | 3-1-1 | Feel the stretch |
| 8 | Face Pulls | 3 | 15–20 | 2-1-2 | Rear delt + rotator health |

**Tempo guide:** 3-1-1 = 3s down, 1s pause, 1s up.

---

## 🔵 DAY 2 — PULL // "The V-Taper Forge"

> **Mantra:** *"Elbows to back pockets."* — Pull with back, not arms.

| # | Exercise | Sets | Reps | Tempo | Cue |
|---|---|---|---|---|---|
| 1 | Lat Pulldown | 4 | 8–10 | 3-1-1 | Wide grip, slight lean |
| 2 | Seated Cable Row | 3 | 10 | 3-1-1 | Chest to pad |
| 3 | Single Arm DB Row | 3 | 10/side | 3-1-1 | Full range, big stretch |
| 4 | Chest-Supported Row | 3 | 10–12 | 3-1-1 | Takes lower back out |
| 5 | Face Pulls | 3 | 15 | 2-1-2 | 3D shoulder look |
| 6 | Rear Delt Fly | 3 | 15 | 2-0-2 | Slight elbow bend |
| 7 | EZ Bar Curl | 3 | 10 | 2-1-2 | No swinging |
| 8 | Hammer Curl | 3 | 10–12 | 2-1-2 | Brachialis = arm width |
| 9 | Incline DB Curl | 2 | 12 | 3-1-1 | Stretches long head for peak |

---

## 🟢 DAY 3 — LEGS + CORE // "The Baki Foundation"

> **Mantra:** *"Small legs = small man."* — Don't be that guy.
> **Bonus:** Heavy legs ↑ testosterone → fat loss everywhere.

| # | Exercise | Sets | Reps | Tempo | Cue |
|---|---|---|---|---|---|
| 1 | Goblet / Back Squat | 4 | 8–10 | 3-1-1 | Knees track over toes |
| 2 | Leg Press | 3 | 10–12 | 3-1-1 | Shoulder-width feet |
| 3 | Romanian Deadlift | 3 | 10–12 | 3-1-1 | Feel hamstrings stretch |
| 4 | Leg Curl | 3 | 12 | 3-1-1 | Slow negative |
| 5 | Leg Extension | 3 | 12 | 2-1-2 | Squeeze at top |
| 6 | Walking Lunges | 3 | 12/side | 2-1-1 | Glute builder |
| 7 | Standing Calf Raises | 4 | 15–20 | 3-1-1 | Full stretch bottom |

### Core Gauntlet (after legs)

| Exercise | Sets | Reps / Time |
|---|---|---|
| Hanging Leg Raises | 3 | 12–15 |
| Plank | 3 | 45–60 sec |
| Ab Wheel Rollout | 3 | 10–12 |
| Bicycle Crunches | 3 | 20 |

> **Truth:** Abs are built in the gym, revealed in the kitchen.

---

## 🟡 DAY 5 — UPPER AESTHETIC // "The Pump Domain"

> **Mantra:** *"Pump = growth signal."* Higher reps, shorter rest, maximum tension.
> **Rest:** 45–60s between sets.

| # | Exercise | Sets | Reps | Cue |
|---|---|---|---|---|
| 1 | Incline DB Press | 3 | 10–12 | Lighter, controlled |
| 2 | Chest-Supported Row | 3 | 10–12 | Squeeze at peak |
| 3 | Arnold Press | 3 | 10–12 | 360° shoulder hit |
| 4 | Cable / DB Fly | 3 | 12–15 | Inner chest pop |
| 5 | Lateral Raises | 4 | 15–20 | Medial delt width |
| 6 | EZ / DB Curl | 3 | 12 | Slow, controlled |
| 7 | Tricep Dips / Pushdown | 3 | 10–12 | Lockout full |
| 8 | Rear Delt Fly | 3 | 15 | Always train these |

### Pump Finisher (2 rounds, 60s rest between rounds, no rest between exercises)

- Push-ups — Max reps
- Lateral Raises — 20 reps (light)
- Hammer Curls — 15 reps

---

## ❤️ CARDIO PROTOCOL ── Burn Without Losing Muscle

| Type | When | Duration | Intensity |
|---|---|---|---|
| LISS Walk | Thursday | 30–45 min | 60–65% max HR |
| Incline Treadmill | Saturday | 30–40 min | 65–70% max HR |
| Cycling (opt) | Any | 30 min | Moderate |
| HIIT (max 1×/wk) | Thu only | 15–20 min | High |

**Daily step goal: 8,000–10,000** — break it up across the day.

> [!warning] **No intense cardio on leg day.** Saves your joints and your gains.

---

## 📈 PROGRESSIVE OVERLOAD LAW

> [!success] **Double Progression Method — The Meta**
>
> 1. Start exercise at bottom of rep range (e.g., 8 reps)
> 2. Each week, add 1–2 reps per set until you hit the top
> 3. Once you hit top reps on ALL sets → **increase weight by 1–2.5 kg**
> 4. Drop to bottom of range → repeat

**Example — Incline DB Press:**

| Week | Weight | Reps |
|---|---|---|
| 1 | 20 kg | 8, 8, 7, 7 |
| 2 | 20 kg | 9, 9, 8, 8 |
| 3 | 20 kg | 10, 10, 10, 9 |
| 4 | **22.5 kg** | 8, 8, 7, 7 ← new cycle |

---

## 🔄 DELOAD PROTOCOL ── Every 4–6 Weeks

When your Dashboard flags deload (low energy, poor sleep, stalled lifts):

| Variable | Change |
|---|---|
| Volume (sets) | Cut by **40%** |
| Intensity (weight) | Keep **70–80%** of normal |
| Reps | Stay in range, leave 3–4 reps in tank |
| Cardio | Light LISS only |
| Sleep | +1 hour minimum |

**One week. Then back to war.**

---

## 💊 SUPPLEMENT STACK (Optional)

> [!warning] **Supplements are NOT magic.** Food first, always.

| Supplement | Dose | Timing | Purpose |
|---|---|---|---|
| Whey Protein | 25–30g | Post-workout / any meal | Hit protein targets |
| Creatine Monohydrate | 5g | Daily | Strength + muscle volume |
| Caffeine / Pre-workout | 1 serving | 30 min pre-gym | Energy + focus |
| Omega-3 Fish Oil | 2–3g | With meals | Anti-inflammatory |
| Vitamin D3 | 2000–4000 IU | Morning | Hormones, mood, energy |
| Magnesium Glycinate | 300–400mg | Before bed | Sleep + recovery |

---

## 🗓️ 12-WEEK PHASE PLAN

| Phase | Weeks | Calories | Focus |
|---|---|---|---|
| 🧱 **Foundation** | 1–3 | 2500 | Learn lifts, build habits |
| 🔥 **Progress** | 4–8 | 2400–2500 | Push weights up |
| ⚔️ **Accelerate** | 9–12 | 2300–2400 | Dial in diet + more cardio |

---

[[🏯 Dashboard]] • [[Templates/📖 Daily Log Template]] • [[Templates/🗓️ Weekly Check-in Template]] • [[📚 Exercise Library]]
