---
tags: [dashboard, fitness]
cssclass: cursed-dashboard
---

# 🏯 THE DOJO ── Command Center

> [!quote] **"The weak have no say in this world. So I will become strong."**
> ─ *From Baki, Saitama, Gojo — and you.*

```
╔══════════════════════════════════════════════════════════════╗
║  MISSION: 90 kg  ➜  Lean Aesthetic Physique                  ║
║  SYSTEM:  Level E Hunter  ➜  S-Rank Shadow Monarch           ║
║  RULE #1: Discipline > Motivation. Always.                   ║
╚══════════════════════════════════════════════════════════════╝
```

---

## ⚡ CURRENT STATUS ── Hunter Profile

> [!success]+ 📊 **Live Stats** *(auto-updates from your daily logs)*
> ```dataviewjs
> const pages = dv.pages('#daily-log').sort(p => p.date, 'desc');
> const latest = pages[0];
> const startWeight = 90;
> const current = latest?.weight_kg || startWeight;
> const lost = (startWeight - current).toFixed(1);
> const totalDays = pages.length;
> const trained = pages.where(p => p.workout_done == true).length;
> const compliance = totalDays > 0 ? ((trained/totalDays)*100).toFixed(0) : 0;
>
> dv.paragraph(`
> | Stat | Value |
> |------|-------|
> | 🩸 **Current Weight** | **${current} kg** |
> | 🔻 **Total Lost** | **${lost} kg** |
> | 📅 **Days Logged** | **${totalDays}** |
> | 🏋️ **Workouts Done** | **${trained}** |
> | 🔥 **Training Compliance** | **${compliance}%** |
> `);
> ```

---

## 🎖️ CURRENT RANK ── Hunter Progression System

> [!info]+ 🏅 **Your Rank Based on Progress**
> ```dataviewjs
> const pages = dv.pages('#daily-log');
> const lost = 90 - (pages.sort(p => p.date, 'desc')[0]?.weight_kg || 90);
> let rank = "🟤 E-Rank ── Civilian";
> let quote = "Every Shadow Monarch starts as an E-Rank. Keep going.";
> if (lost >= 2) { rank = "🟢 D-Rank ── Awakened"; quote = "The system noticed you. Cursed energy flowing."; }
> if (lost >= 5) { rank = "🔵 C-Rank ── Rising Hunter"; quote = "You've outgrown the weak. The real path begins."; }
> if (lost >= 8) { rank = "🟣 B-Rank ── Domain User"; quote = "Consistency has become your domain. Few reach here."; }
> if (lost >= 12) { rank = "🟡 A-Rank ── Special Grade"; quote = "You're in rare air. Yūji and Megumi nod at you."; }
> if (lost >= 15) { rank = "🔴 S-Rank ── Shadow Monarch"; quote = "The transformation is complete. You ARE the weapon."; }
> dv.paragraph(`### ${rank}\n> *"${quote}"*`);
> ```

---

## 🎯 DAILY NON-NEGOTIABLES ── The Five Pillars

| Pillar | Target | Why |
|---|---|---|
| 🍖 **Calories** | **2,500 kcal** | Fuel the fight — not too much, not too little |
| 🥩 **Protein** | **180 g** | Every gram = cursed energy stored in muscle |
| 💧 **Water** | **3.5 L** | Recovery runs on hydration |
| 👟 **Steps** | **8,000 – 10,000** | Stealth cardio. Every shadow counts. |
| 😴 **Sleep** | **7 – 9 hrs** | Gojo sleeps. You should too. |

---

## 🔥 HABIT STREAK TRACKER ── Consistency is Power

> [!tip]+ 🪷 **Active Streaks** *(consecutive days hitting target)*
> ```dataviewjs
> const pages = dv.pages('#daily-log').sort(p => p.date, 'desc').array();
>
> function streak(field, threshold, op = '>=') {
>   let count = 0;
>   for (const p of pages) {
>     const v = p[field];
>     if (v == null) break;
>     const ok = op === '>=' ? v >= threshold : v <= threshold;
>     if (ok) count++; else break;
>   }
>   return count;
> }
>
> const proteinStreak = streak('protein_actual', 170);
> const calorieStreak = streak('calories_actual', 2700, '<=');
> const stepStreak = streak('steps', 8000);
> const waterStreak = streak('water_L', 3);
> const sleepStreak = streak('sleep_hrs', 7);
> const workoutStreak = (() => {
>   let c = 0;
>   for (const p of pages) {
>     if (p.workout_done == true || p.rest_day == true) c++;
>     else break;
>   }
>   return c;
> })();
>
> const fire = n => n >= 7 ? '🔥🔥🔥' : n >= 3 ? '🔥' : '💨';
>
> dv.paragraph(`
> | Habit | Streak | Status |
> |-------|--------|--------|
> | 🥩 Protein ≥ 170g | **${proteinStreak} days** | ${fire(proteinStreak)} |
> | 🔥 Calories ≤ 2700 | **${calorieStreak} days** | ${fire(calorieStreak)} |
> | 👟 Steps ≥ 8k | **${stepStreak} days** | ${fire(stepStreak)} |
> | 💧 Water ≥ 3L | **${waterStreak} days** | ${fire(waterStreak)} |
> | 😴 Sleep ≥ 7h | **${sleepStreak} days** | ${fire(sleepStreak)} |
> | 🏋️ Training on Plan | **${workoutStreak} days** | ${fire(workoutStreak)} |
> `);
> ```

---

## 📈 WEIGHT PROGRESSION ── The Transformation Arc

> [!example]+ ⚖️ **Weight Trend — Last 30 Days**
> ```dataview
> TABLE WITHOUT ID
>   file.link AS "Date",
>   weight_kg AS "Weight (kg)",
>   round(90 - weight_kg, 1) AS "Lost"
> FROM #daily-log
> WHERE weight_kg
> SORT date DESC
> LIMIT 30
> ```

> [!chart] 📉 **Weight Chart**
> ```dataviewjs
> const pages = dv.pages('#daily-log')
>   .where(p => p.weight_kg)
>   .sort(p => p.date, 'asc');
>
> if (pages.length === 0) {
>   dv.paragraph("_No weight data yet. Log your first day to see the chart._");
> } else {
>   const labels = pages.map(p => p.date?.toFormat?.('MMM dd') || '').array();
>   const weights = pages.map(p => p.weight_kg).array();
>   const chartData = {
>     type: 'line',
>     data: {
>       labels: labels,
>       datasets: [{
>         label: 'Weight (kg)',
>         data: weights,
>         borderColor: '#c9302c',
>         backgroundColor: 'rgba(201, 48, 44, 0.15)',
>         tension: 0.3,
>         fill: true
>       }]
>     }
>   };
>   window.renderChart(chartData, this.container);
> }
> ```
> *Needs the **Obsidian Charts** plugin. If not installed, use the table above.*

---

## 📆 MONTHLY CALORIE & PROTEIN VIEW

> [!abstract]+ 🍱 **Last 30 Days — Nutrition**
> ```dataview
> TABLE WITHOUT ID
>   file.link AS "Day",
>   calories_actual AS "Cal",
>   protein_actual AS "Protein",
>   choice(calories_actual <= 2600 AND calories_actual >= 2300, "✅", "⚠️") AS "Cal OK",
>   choice(protein_actual >= 170, "✅", "❌") AS "Prot OK"
> FROM #daily-log
> WHERE calories_actual
> SORT date DESC
> LIMIT 30
> ```

> [!note]+ 📊 **Monthly Averages**
> ```dataviewjs
> const pages = dv.pages('#daily-log')
>   .where(p => p.calories_actual && p.date >= dv.date('today').minus({days: 30}));
> const n = pages.length;
> if (n === 0) { dv.paragraph("_No nutrition data in last 30 days._"); }
> else {
>   const avgCal = (pages.map(p => p.calories_actual).array().reduce((a,b) => a+b, 0) / n).toFixed(0);
>   const avgP   = (pages.map(p => p.protein_actual || 0).array().reduce((a,b) => a+b, 0) / n).toFixed(0);
>   const avgW   = (pages.map(p => p.water_L || 0).array().reduce((a,b) => a+b, 0) / n).toFixed(1);
>   const avgS   = (pages.map(p => p.steps || 0).array().reduce((a,b) => a+b, 0) / n).toFixed(0);
>   const avgSleep = (pages.map(p => p.sleep_hrs || 0).array().reduce((a,b) => a+b, 0) / n).toFixed(1);
>   dv.paragraph(`
> | Metric | 30-day Avg | Target | Verdict |
> |---|---|---|---|
> | 🔥 Calories | **${avgCal}** | 2500 | ${Math.abs(avgCal - 2500) < 150 ? '✅ Locked in' : '⚠️ Drift'} |
> | 🥩 Protein | **${avgP}g** | 180g | ${avgP >= 170 ? '✅ Cursed reserves full' : '❌ Refill needed'} |
> | 💧 Water | **${avgW}L** | 3.5L | ${avgW >= 3 ? '✅' : '⚠️'} |
> | 👟 Steps | **${avgS}** | 8000+ | ${avgS >= 8000 ? '✅' : '⚠️'} |
> | 😴 Sleep | **${avgSleep}h** | 7-9h | ${avgSleep >= 7 ? '✅' : '❌ Recover harder'} |
> `);
> }
> ```

---

## 🗓️ MONTHLY WORKOUT VIEW ── Training Calendar

> [!map]+ 🏋️ **Last 30 Workouts**
> ```dataview
> TABLE WITHOUT ID
>   file.link AS "Date",
>   workout_type AS "Session",
>   choice(workout_done, "✅", "❌") AS "Done",
>   training_score AS "Score /10"
> FROM #daily-log
> WHERE workout_type AND workout_type != ""
> SORT date DESC
> LIMIT 30
> ```

> [!check]+ 💪 **Split Compliance — Last 30 Days**
> ```dataviewjs
> const pages = dv.pages('#daily-log')
>   .where(p => p.date >= dv.date('today').minus({days: 30}) && p.workout_done == true);
> const push  = pages.where(p => p.workout_type == "Push").length;
> const pull  = pages.where(p => p.workout_type == "Pull").length;
> const legs  = pages.where(p => p.workout_type == "Legs").length;
> const upper = pages.where(p => p.workout_type == "Upper").length;
> const cardio = pages.where(p => p.workout_type == "Cardio").length;
> dv.paragraph(`
> | Session | Completed (last 30d) | Target |
> |---|---|---|
> | 🔴 Push | **${push}** | ~4 |
> | 🔵 Pull | **${pull}** | ~4 |
> | 🟢 Legs | **${legs}** | ~4 |
> | 🟡 Upper | **${upper}** | ~4 |
> | ❤️ Cardio | **${cardio}** | ~8 |
> `);
> ```

---

## 🏆 PERSONAL RECORDS ── Hall of Fame

> [!star]+ 💎 **Your Current PRs**
> ```dataview
> TABLE WITHOUT ID
>   exercise AS "Exercise",
>   weight_kg + " kg" AS "Weight",
>   reps AS "Reps",
>   date AS "Set On"
> FROM "PR Tracker"
> WHERE exercise
> SORT weight_kg DESC
> ```
> Log a new PR in `📁 PR Tracker/` — one file per lift.

---

## 🧠 MOOD × TRAINING CORRELATION

> [!brain]+ 🧬 **How You Train Based on Energy/Mood**
> ```dataviewjs
> const pages = dv.pages('#daily-log')
>   .where(p => p.energy && p.training_score);
> if (pages.length < 3) { dv.paragraph("_Need at least 3 logs with energy + training score._"); }
> else {
>   const highE = pages.where(p => p.energy >= 7);
>   const lowE = pages.where(p => p.energy <= 5);
>   const highAvg = highE.length ? (highE.map(p => p.training_score).array().reduce((a,b)=>a+b,0) / highE.length).toFixed(1) : 'N/A';
>   const lowAvg  = lowE.length ? (lowE.map(p => p.training_score).array().reduce((a,b)=>a+b,0) / lowE.length).toFixed(1) : 'N/A';
>
>   const goodMood = pages.where(p => p.mood >= 7);
>   const badMood = pages.where(p => p.mood <= 5);
>   const gmAvg = goodMood.length ? (goodMood.map(p => p.training_score).array().reduce((a,b)=>a+b,0) / goodMood.length).toFixed(1) : 'N/A';
>   const bmAvg = badMood.length ? (badMood.map(p => p.training_score).array().reduce((a,b)=>a+b,0) / badMood.length).toFixed(1) : 'N/A';
>
>   dv.paragraph(`
> | State | Avg Training Score | Samples |
> |---|---|---|
> | ⚡ High Energy (≥7) | **${highAvg}/10** | ${highE.length} days |
> | 🪫 Low Energy (≤5) | **${lowAvg}/10** | ${lowE.length} days |
> | 😊 Good Mood (≥7) | **${gmAvg}/10** | ${goodMood.length} days |
> | 😔 Low Mood (≤5) | **${bmAvg}/10** | ${badMood.length} days |
>
> **Insight:** ${highAvg !== 'N/A' && lowAvg !== 'N/A' && parseFloat(highAvg) - parseFloat(lowAvg) >= 1.5 ? '→ Your training tanks when energy is low. Prioritize sleep & recovery.' : '→ Your performance is stable across energy levels. Strong discipline.'}
> `);
> }
> ```

---

## 🌀 DELOAD RADAR ── Recovery Alert System

> [!warning]+ 🛡️ **Should You Deload?**
> ```dataviewjs
> const pages = dv.pages('#daily-log').sort(p => p.date, 'desc');
> const last7 = pages.limit(7);
> const last14 = pages.limit(14);
>
> const avgEnergy7 = last7.length ? (last7.map(p => p.energy || 0).array().reduce((a,b)=>a+b,0) / last7.length).toFixed(1) : 0;
> const avgSleep7 = last7.length ? (last7.map(p => p.sleep_hrs || 0).array().reduce((a,b)=>a+b,0) / last7.length).toFixed(1) : 0;
> const avgTrain7 = last7.where(p => p.training_score).length ? (last7.where(p => p.training_score).map(p => p.training_score).array().reduce((a,b)=>a+b,0) / last7.where(p => p.training_score).length).toFixed(1) : 0;
>
> const totalWorkouts = pages.where(p => p.workout_done == true).length;
> const weeksOfWork = Math.floor(totalWorkouts / 4);
>
> let alerts = [];
> if (avgEnergy7 && avgEnergy7 < 5) alerts.push(`⚠️ Avg energy is **${avgEnergy7}/10** (low)`);
> if (avgSleep7 && avgSleep7 < 6.5) alerts.push(`⚠️ Avg sleep is **${avgSleep7}h** (under-recovered)`);
> if (avgTrain7 && avgTrain7 < 6) alerts.push(`⚠️ Training scores averaging **${avgTrain7}/10**`);
> if (weeksOfWork >= 5) alerts.push(`🔄 **${weeksOfWork} weeks** of training accumulated — consider a deload`);
>
> if (alerts.length === 0) {
>   dv.paragraph(`✅ **Status: PUSH** — No deload signals. Keep stacking wins.`);
> } else {
>   dv.paragraph(`🛑 **Status: CHECK YOURSELF**\n\n${alerts.join('\n\n')}\n\n→ Consider a **deload week**: cut volume 40%, keep intensity 70%, prioritize sleep.`);
> }
> ```

---

## 📏 BODY MEASUREMENTS ── Tape Never Lies

| Date | Waist (cm) | Hips (cm) | Chest (cm) | Shoulder (cm) | Notes |
|------|-----------|-----------|-----------|--------------|-------|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

*Measure every 2 weeks. Morning, same time.*

---

## 📸 PROGRESS PHOTOS LOG

```dataview
TABLE WITHOUT ID
  file.link AS "Day",
  photo_taken AS "Photo?"
FROM #daily-log
WHERE photo_taken = true
SORT date DESC
LIMIT 10
```

---

## 📜 QUICK JUMP ── Dojo Navigation

- 🗡️ [[💥 Workout Plan]] — Your training bible
- 📅 [[Templates/📖 Daily Log Template]] — Duplicate daily
- 📊 [[Templates/🗓️ Weekly Check-in Template]] — Duplicate weekly
- 🏆 `📁 PR Tracker/` — Log your personal records
- 📚 [[📚 Exercise Library]] — Form cues & alternatives
- 🧘 [[🧘 Mindset & Protocols]] — The philosophy

---

## 💭 FLOATING NOTES ── Drop Ideas Here

> [!note]+ 🗒️ **Scratchpad**
> *(write anything here — insights, random thoughts, things to try)*
>
> -
> -
> -

---

## 🔔 RECENT LOGS — Last 7 Days

```dataview
TABLE WITHOUT ID
  file.link AS "Day",
  weight_kg AS "Wt",
  calories_actual AS "Cal",
  protein_actual AS "Prot",
  steps AS "Steps",
  overall_score AS "Score"
FROM #daily-log
SORT date DESC
LIMIT 7
```

---

```
      .-=-.          .--,
      /  !  \        / /
     |   ø   |      / /
      \  ∇  /.--.__/ /
       `.-=≡≡=.-'""
   ── THE SHADOW ARMY STANDS WITH YOU ──
```

*Version 2.0 ── Cursed Aesthetic Protocol*
