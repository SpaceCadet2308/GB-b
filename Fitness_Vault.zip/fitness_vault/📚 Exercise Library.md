---
tags: [reference, exercise-library]
---

# 📚 EXERCISE LIBRARY ── Form Grimoire

> Quick-reference for every lift in your program. Bookmark this.

---

## 🔴 PUSH MOVEMENTS

### Incline DB Press
- **Setup:** Bench at 30°. DBs at shoulder height, palms forward.
- **Execution:** Press up & slightly in. Elbows ~45° from torso. Full stretch at bottom, don't lock at top.
- **Cue:** *"Crush the ceiling with your chest."*
- **Common mistake:** Bench too high (becomes shoulder press) — 30° max.

### Flat DB Press
- **Setup:** Flat bench, DBs at chest, palms forward.
- **Execution:** Press up in arc, touch lightly at top, lower to deep stretch.
- **Cue:** *"Chest leads, arms follow."*

### Machine Chest Press
- **Setup:** Seat height so handles align with lower chest.
- **Execution:** Press, squeeze hard at top, slow return.
- **Cue:** *"Push your chest into the pad, not the handles away."*

### Seated DB Shoulder Press
- **Setup:** Upright bench, DBs at shoulder level.
- **Execution:** Press up, don't lock out, controlled descent.
- **Cue:** *"Elbows slightly in front of your body, not flared."*

### Lateral Raises
- **Setup:** Standing, DBs at sides, slight elbow bend.
- **Execution:** Raise to shoulder height, lead with **elbows**, slight forward lean.
- **Cue:** *"Pour a pitcher of water out at the top."*
- **Common mistake:** Going too heavy — form trumps weight here.

### Cable Tricep Pushdown
- **Setup:** Cable at top, rope or bar attachment.
- **Execution:** Elbows glued to sides, push down, squeeze at bottom.
- **Cue:** *"Only your forearms move."*

### Overhead DB Tricep Extension
- **Setup:** Seated, single DB held with both hands overhead.
- **Execution:** Lower behind head, full stretch, press up.
- **Cue:** *"Elbows pointed at the sky, don't flare."*

### Face Pulls
- **Setup:** Cable at upper chest height, rope attachment.
- **Execution:** Pull toward face, hands flare out, pinch shoulder blades.
- **Cue:** *"Show me your armpits."* — external rotation is key.

---

## 🔵 PULL MOVEMENTS

### Lat Pulldown
- **Setup:** Wide grip, slightly wider than shoulders, lean back ~15°.
- **Execution:** Pull bar to upper chest, drive elbows down & back.
- **Cue:** *"Elbows to back pockets."*

### Seated Cable Row
- **Setup:** Neutral grip attachment, feet planted.
- **Execution:** Pull to lower chest, squeeze shoulder blades, slow return.
- **Cue:** *"Chest out, pull with elbows."*

### Single Arm DB Row
- **Setup:** Knee & hand on bench, back flat, DB hanging.
- **Execution:** Row up to hip, elbow close, full stretch at bottom.
- **Cue:** *"Saw the wood, don't shrug."*

### Chest-Supported Row
- **Setup:** Face down on incline bench.
- **Execution:** Row weights up, squeeze back, controlled down.
- **Cue:** *"Let the bench take your ego out of it."*

### Rear Delt Fly
- **Setup:** Bent over or chest-supported, light DBs, slight elbow bend.
- **Execution:** Raise arms out to sides in arc, squeeze rear delts.
- **Cue:** *"Thumbs point down at top — hits rear delts harder."*

### EZ Bar Curl
- **Setup:** Shoulder-width grip on EZ bar.
- **Execution:** Curl up, elbows stationary, squeeze biceps.
- **Cue:** *"Elbows are hinges, not levers."*

### Hammer Curl
- **Setup:** Neutral grip (palms facing each other).
- **Execution:** Curl up, keep wrists neutral.
- **Cue:** *"Brachialis + brachioradialis = arm thickness."*

### Incline DB Curl
- **Setup:** Incline bench 45–60°, arms hanging straight.
- **Execution:** Curl up, stretched start, peak contraction top.
- **Cue:** *"Long head of bicep stretch = peak growth."*

---

## 🟢 LEG MOVEMENTS

### Goblet / Back Squat
- **Setup:** Feet shoulder-width, toes slightly out.
- **Execution:** Sit down & back, chest up, knees track over toes. Go to parallel or below.
- **Cue:** *"Spread the floor with your feet."*

### Leg Press
- **Setup:** Feet shoulder-width on platform, back flat.
- **Execution:** Lower to ~90° knee angle, press up without locking out.
- **Cue:** *"Don't let lower back round — stop before that."*

### Romanian Deadlift (RDL)
- **Setup:** Feet hip-width, DBs in front, slight knee bend.
- **Execution:** Hinge at hips, push butt back, lower until hamstring stretch.
- **Cue:** *"Close the car door with your butt."*

### Leg Curl
- **Setup:** Machine set to your leg length.
- **Execution:** Curl heels to butt, slow negative.
- **Cue:** *"Point toes down for more hamstring."*

### Leg Extension
- **Setup:** Pad on top of shin, seat adjusted.
- **Execution:** Extend legs, squeeze at top for 1 sec, slow down.
- **Cue:** *"Don't slam at the top."*

### Walking Lunges
- **Setup:** DBs at sides, upright posture.
- **Execution:** Long step, back knee near floor, drive up through front heel.
- **Cue:** *"Long step = glutes. Short step = quads."*

### Standing Calf Raises
- **Setup:** Balls of feet on raised surface.
- **Execution:** Full stretch at bottom, rise to full contraction at top.
- **Cue:** *"Pause 1 sec at top AND bottom."*

---

## 🧊 CORE MOVEMENTS

### Hanging Leg Raises
- **Setup:** Hanging from bar, shoulders engaged.
- **Execution:** Raise legs straight, control down.
- **Cue:** *"Curl your pelvis up, not just legs."*

### Plank
- **Setup:** Forearms down, body straight line.
- **Execution:** Brace hard, glutes squeezed, hold.
- **Cue:** *"Pull elbows toward toes — isometric tension."*

### Ab Wheel Rollout
- **Setup:** Knees on pad (or toes if advanced).
- **Execution:** Roll out, brace core, return without arching.
- **Cue:** *"Tuck tailbone slightly to protect lower back."*

### Bicycle Crunches
- **Setup:** On back, hands behind head, knees bent.
- **Execution:** Opposite elbow to knee, controlled.
- **Cue:** *"Rotate through torso, not neck."*

---

## 🌀 SWAP OPTIONS ── If Equipment is Taken

| Planned | Alternative |
|---|---|
| Incline DB Press | Incline Machine Press / Push-ups (decline) |
| Flat DB Press | Floor Press / Dips |
| Lat Pulldown | Pull-ups / Assisted Pull-ups |
| Seated Row | Single-arm Cable Row / Inverted Row |
| Shoulder Press | Arnold Press / Landmine Press |
| Lateral Raise | Cable Lateral / Machine Lateral |
| Squat | Leg Press / Bulgarian Split Squat |
| RDL | Hip Thrust / Cable Pull-Through |
| Leg Curl | Swiss Ball Leg Curl / Nordic Curl |

---

[[🏯 Dashboard]] • [[💥 Workout Plan]]
