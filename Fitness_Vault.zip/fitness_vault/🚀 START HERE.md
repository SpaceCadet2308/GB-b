---
tags: [setup, guide]
---

# 🚀 START HERE ── System Initialization

> **Welcome, Hunter.** This vault is a full fitness automation system.
> Follow this setup ONCE. Then just open your daily log and log.

---

## 📁 VAULT STRUCTURE

```
📁 Fitness Vault/
├── 🏯 Dashboard.md                  ← Your command center (auto-updates)
├── 💥 Workout Plan.md               ← The training bible (reference)
├── 📚 Exercise Library.md           ← Form cues for every lift
├── 🧘 Mindset & Protocols.md        ← Philosophy & when stuck
├── 🚀 START HERE.md                 ← This file
│
├── 📁 Templates/
│   ├── 📖 Daily Log Template.md     ← Duplicate every day
│   └── 🗓️ Weekly Check-in Template.md ← Duplicate every Sunday
│
├── 📁 Daily Logs/                   ← Your dated daily logs go here
├── 📁 Weekly Reviews/               ← Your weekly reviews
├── 📁 PR Tracker/                   ← One file per personal record
│   └── 🏆 PR Template.md
└── 📁 Progress Photos/              ← Add photo links / files
```

---

## ⚙️ REQUIRED PLUGINS ── Install These First

> The automation won't work without these. Takes 2 minutes.

### 1. **Dataview** ⭐ (REQUIRED)
- **Why:** All auto-tables and stats on the Dashboard use this.
- **Install:** Settings → Community Plugins → Browse → search `Dataview` → Install → Enable.
- **Crucial setting:** Open Dataview settings → turn **ON** `Enable JavaScript Queries`. Without this, half the dashboard won't render.

### 2. **Templater** ⭐ (REQUIRED for date auto-fill)
- **Why:** Makes `{{date:YYYY-MM-DD}}` auto-fill when you create a new daily log.
- **Install:** Settings → Community Plugins → Browse → search `Templater` → Install → Enable.
- **Setting:** Templater settings → Template folder location: `Templates`.

### 3. **Periodic Notes** ⭐ (REQUIRED for daily log hotkey)
- **Why:** Press one hotkey to create today's log automatically.
- **Install:** Settings → Community Plugins → Browse → search `Periodic Notes` → Install → Enable.
- **Setup:**
  - Enable **Daily Notes**
  - Format: `YYYY-MM-DD dddd`
  - Template: `Templates/📖 Daily Log Template`
  - Folder: `Daily Logs`

### 4. **Obsidian Charts** 🔥 (OPTIONAL but recommended)
- **Why:** Makes the weight chart on the Dashboard render visually.
- **Install:** Community Plugins → `Obsidian Charts` → Install → Enable.
- If not installed, the table version of your weight progression still works.

### 5. **Calendar** 👍 (Nice to have)
- Visual calendar sidebar to jump between daily logs.

---

## 🎯 DAILY WORKFLOW (After Setup)

### Every Morning (30 seconds)
1. Press your Periodic Notes hotkey (or click the calendar icon) → new daily log created.
2. Weigh yourself → fill `weight_kg:` in the frontmatter at top.
3. Log sleep, mood, energy in the morning section.

### Throughout the Day
- Log meals as you eat them (not after).
- Log workout sets during the session.

### Every Evening (2 minutes)
- Update frontmatter totals: `calories_actual`, `protein_actual`, `steps`, `water_L`.
- Set `workout_done: true` if you trained.
- Fill the reflection section.
- Score the day out of 10 in each category.
- **DONE.** Dashboard updates automatically. 🔥

### Every Sunday (10 minutes)
1. Duplicate `Templates/🗓️ Weekly Check-in Template.md`.
2. Put it in `Weekly Reviews/` folder, rename like `Week 05 Review.md`.
3. Fill it in while reviewing your week.
4. Take progress photos (front / side / back).

### When You Hit a PR 🏆
1. Duplicate `PR Tracker/🏆 PR Template.md`.
2. Rename: `[Exercise] PR YYYY-MM-DD`.
3. Fill frontmatter. It auto-appears on your Dashboard.

---

## ⚡ CRITICAL — FRONTMATTER FIELDS THAT DRIVE THE DASHBOARD

Your Daily Log has a **frontmatter block** (the `---` section at the very top). The Dashboard reads these fields. **Fill them in.**

| Field | Type | Example |
|---|---|---|
| `date` | date | `2024-11-15` |
| `weight_kg` | number | `89.4` |
| `calories_actual` | number | `2480` |
| `protein_actual` | number | `185` |
| `water_L` | number | `3.6` |
| `steps` | number | `9200` |
| `sleep_hrs` | number | `7.5` |
| `energy` | number (1–10) | `8` |
| `mood` | number (1–10) | `7` |
| `workout_type` | text | `Push` / `Pull` / `Legs` / `Upper` / `Cardio` / `Rest` |
| `workout_done` | true/false | `true` |
| `rest_day` | true/false | `false` |
| `training_score` | number | `8` |
| `overall_score` | number | `9` |
| `photo_taken` | true/false | `true` |

> [!danger] **The tables/streaks/rank on your Dashboard are ONLY as accurate as your frontmatter.** Fill those fields honestly every day — that's 90% of the system.

---

## ✅ DAY 1 CHECKLIST

- [ ] Copy this entire vault folder into your Obsidian vaults
- [ ] Open it in Obsidian
- [ ] Install Dataview, Templater, Periodic Notes
- [ ] **Enable JavaScript Queries** in Dataview settings
- [ ] Set Templater's template folder to `Templates`
- [ ] Set Periodic Notes daily template to `Templates/📖 Daily Log Template`
- [ ] Open `🏯 Dashboard.md` — confirm it loads (will be empty until first log)
- [ ] Weigh yourself tomorrow morning
- [ ] Create your first daily log, fill frontmatter
- [ ] Take Week 1 progress photos (Front / Side / Back)
- [ ] Read `🧘 Mindset & Protocols.md` — understand the system's philosophy

---

## 🧩 TROUBLESHOOTING

**Dashboard tables show "0 results" or blank**
→ You haven't created any daily logs yet, OR you forgot to fill the frontmatter `tags: [daily-log, fitness]`.

**JavaScript blocks show code instead of rendering**
→ Enable "JavaScript Queries" in Dataview settings.

**`{{date}}` shows up literally in the file**
→ You didn't create the file via Templater. Either: install Templater + Periodic Notes OR manually type today's date.

**Weight chart doesn't appear**
→ Install the Obsidian Charts plugin. Or rely on the table version below it.

**Rank shows "E-Rank" even though I've lost weight**
→ The script compares latest `weight_kg` to 90. Make sure your latest daily log has `weight_kg:` filled.

---

## 🏯 NAVIGATION

[[🏯 Dashboard]] • [[💥 Workout Plan]] • [[📚 Exercise Library]] • [[🧘 Mindset & Protocols]]

---

```
     「 SYSTEM INITIATED 」
   Welcome to the Hunter's Program.
   The transformation begins on Day 1.
```
