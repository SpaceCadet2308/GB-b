---
date: {{date:YYYY-MM-DD}}
day: {{date:dddd}}
week_number:
weight_kg:
calories_target: 2500
protein_target: 180
calories_actual:
protein_actual:
water_L:
steps:
sleep_hrs:
energy:
mood:
workout_type:
workout_done: false
rest_day: false
training_score:
diet_score:
cardio_score:
sleep_score:
overall_score:
photo_taken: false
tags: [daily-log, fitness]
---

# 📖 Hunter's Log ── {{date:dddd, MMMM D YYYY}}

> [!quote] **"One punch, one rep, one day at a time."**
> *— Today's Mission: Execute the plan. No excuses.*

```
╭──────────────────────────────────────────────╮
│  ⚔️  DAY LOG INITIATED                       │
│  📆  {{date:YYYY-MM-DD}}                            │
│  🎯  Protein 180g │ Cal 2500 │ Steps 8k+     │
╰──────────────────────────────────────────────╯
```

---

## 🌅 MORNING AWAKENING ── Opening Ritual

| Metric | Value |
|---|---|
| ⚖️ **Weight** | ___ kg |
| 😴 **Sleep** | ___ hrs |
| ⚡ **Energy (1–10)** | ___ |
| 🧠 **Mood (1–10)** | ___ |
| 🩸 **Resting HR** *(optional)* | ___ bpm |

> [!tip] **Morning Protocol — The Gojo Six-Eyes Routine**
> 1. Weigh yourself (post-toilet, pre-food)
> 2. Log weight in frontmatter `weight_kg:`
> 3. Drink 500ml water immediately
> 4. Sunlight on face — 5 min
> 5. Review today's training plan

**💭 Morning intention for today:**
>

---

## 🍱 NUTRITION CURSED ENERGY TRACKER

### 🥢 Meal Log

| # | Time | Meal | Protein (g) | Calories |
|---|------|------|------------|---------|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| **TOTAL** | | | **___g** | **___ kcal** |

### ✅ Nutrition Checklist

- [ ] 🥩 Protein ≥ 180g → *Actual: ___g*
- [ ] 🔥 Calories 2300–2600 → *Actual: ___ kcal*
- [ ] 💧 Water ≥ 3.5L → *Actual: ___L*
- [ ] 🚫 No unlogged snacks
- [ ] 📱 Tracked **before** eating, not after

> [!warning] **Hidden calories = stalled progress.** If it entered your mouth, it gets logged.

---

## 🗡️ TRAINING ── Choose Your Path

> **Today is:** 🔴 Push / 🔵 Pull / 🟢 Legs / 🟡 Upper / ❤️ Cardio / 😴 Rest
> *(Update `workout_type:` in frontmatter — use exactly: `Push`, `Pull`, `Legs`, `Upper`, `Cardio`, or `Rest`)*

---

### 🔴 DAY 1 — PUSH // "The Chest-Crushing Strike"

> [!fire] **Focus:** Mind-muscle on chest. 3-sec negatives. Squeeze like you mean it.

| Exercise | Sets × Reps | Weight (kg) | Actual Reps | Felt (1–10) |
|---|---|---|---|---|
| Incline DB Press | 4 × 8–10 | | | |
| Flat DB Press | 3 × 8–10 | | | |
| Machine Chest Press | 3 × 10–12 | | | |
| Seated DB Shoulder Press | 4 × 8–10 | | | |
| Lateral Raises | 4 × 12–15 | | | |
| Cable Tricep Pushdown | 3 × 12–15 | | | |
| Overhead DB Tricep Ext. | 3 × 10–12 | | | |
| Face Pulls | 3 × 15 | | | |

---

### 🔵 DAY 2 — PULL // "The V-Taper Forge"

> [!fire] **Focus:** Pull with ELBOWS, not hands. Think "elbows to back pockets."

| Exercise | Sets × Reps | Weight (kg) | Actual Reps | Felt (1–10) |
|---|---|---|---|---|
| Lat Pulldown | 4 × 8–10 | | | |
| Seated Cable Row | 3 × 10 | | | |
| Single Arm DB Row | 3 × 10 each | | | |
| Chest-Supported Row | 3 × 10–12 | | | |
| Face Pulls | 3 × 15 | | | |
| Rear Delt Fly | 3 × 15 | | | |
| EZ Bar Curl | 3 × 10 | | | |
| Hammer Curl | 3 × 10–12 | | | |
| Incline DB Curl | 2 × 12 | | | |

---

### 🟢 DAY 3 — LEGS + CORE // "The Baki Foundation"

> [!fire] **Focus:** Full depth. Feel the stretch. Legs = testosterone = fat loss everywhere.

| Exercise | Sets × Reps | Weight (kg) | Actual Reps | Felt (1–10) |
|---|---|---|---|---|
| Squat / Goblet Squat | 4 × 8–10 | | | |
| Leg Press | 3 × 10–12 | | | |
| Romanian Deadlift | 3 × 10–12 | | | |
| Leg Curl | 3 × 12 | | | |
| Leg Extension | 3 × 12 | | | |
| Walking Lunges | 3 × 12 each | | | |
| Standing Calf Raises | 4 × 15–20 | | | |

**Core Gauntlet (after legs):**

| Exercise | Sets | Reps/Time | ✓ |
|---|---|---|---|
| Hanging Leg Raises | 3 | 12–15 | ☐ |
| Plank | 3 | 45–60 sec | ☐ |
| Ab Wheel Rollout | 3 | 10–12 | ☐ |
| Bicycle Crunches | 3 | 20 | ☐ |

---

### 🟡 DAY 5 — UPPER AESTHETIC // "The Pump Domain"

> [!fire] **Focus:** Higher reps. Feel every fiber. Pump = growth signal.

| Exercise | Sets × Reps | Weight (kg) | Actual Reps | Felt (1–10) |
|---|---|---|---|---|
| Incline DB Press | 3 × 10–12 | | | |
| Chest-Supported Row | 3 × 10–12 | | | |
| Arnold Press | 3 × 10–12 | | | |
| Cable / Pec Fly | 3 × 12–15 | | | |
| Lateral Raises | 4 × 15–20 | | | |
| EZ Bar / DB Curl | 3 × 12 | | | |
| Tricep Dips / Pushdown | 3 × 10–12 | | | |
| Rear Delt Fly | 3 × 15 | | | |

**Finisher Circuit** *(2 rounds, 60s rest between rounds):*
- ☐ Push-ups — Max reps
- ☐ Lateral Raises — 20 reps (light)
- ☐ Hammer Curls — 15 reps

---

## 🏅 PR ALERT ── Did You Break a Record?

> If you hit a new PR today (any lift, any rep count):
> 1. Go to `📁 PR Tracker/` folder
> 2. Create a new file: `[Exercise] PR YYYY-MM-DD`
> 3. Add frontmatter: `exercise:`, `weight_kg:`, `reps:`, `date:`
> 4. It will auto-appear on your Dashboard 🏆

**Any PRs today?**
>

---

## ❤️ CARDIO + STEP COUNT

| Type | Duration | Intensity | Steps |
|---|---|---|---|
| | | | |

- [ ] Cardio done
- [ ] 8,000+ steps hit — *Today: ___*

---

## 🌙 EVENING COUNCIL ── Day Sealed

### ✅ End-of-Day Checklist
- [ ] 🏋️ Workout completed *(tick `workout_done: true` in frontmatter)*
- [ ] 🥩 Protein goal hit
- [ ] 🔥 Calories on target
- [ ] 💧 Water hit
- [ ] 👟 Steps ≥ 8k
- [ ] 📸 Progress photo (if Sunday)
- [ ] 😴 In bed by ___:___

---

## 🪞 REFLECTION — Saitama's Log

**🔥 What WON today?**
>

**🪫 What slipped?**
>

**🎯 Tomorrow's #1 priority:**
>

**💡 Insight / lesson:**
>

---

## 🎖️ DAILY SCORECARD

| Category | Score /10 |
|---|---|
| 🍱 Diet | ___ |
| 🏋️ Training | ___ |
| ❤️ Cardio / Steps | ___ |
| 😴 Sleep | ___ |
| ⭐ **OVERALL** | ___ |

*(Update the frontmatter scores so the dashboard picks them up)*

---

## 📅 NAVIGATION

[[🏯 Dashboard]] • [[💥 Workout Plan]] • [[Templates/🗓️ Weekly Check-in Template]]

---

```
    「 END OF LOG 」
    The shadow grows stronger. Rest well, hunter.
```
