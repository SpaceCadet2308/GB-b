---
date: {{date:YYYY-MM-DD}}
week_number:
avg_weight_kg:
waist_cm:
hips_cm:
diet_score:
training_score:
cardio_score:
sleep_score:
overall_score:
workouts_completed:
tags: [weekly-review, fitness]
---

# 🗓️ Weekly Council — Week ___

> [!quote] **"A week of consistency is worth a month of hype."**

```
═══════════════════════════════════════════════
   WEEK REVIEW • {{date:MMM D, YYYY}}
   Protocol: Audit → Learn → Adjust → Attack
═══════════════════════════════════════════════
```

---

## ⚖️ BODY METRICS ── The Hard Numbers

| Metric | Last Week | This Week | Δ Change |
|---|---|---|---|
| Monday Weight | ___ kg | ___ kg | ___ kg |
| Friday Weight | ___ kg | ___ kg | ___ kg |
| **Average Weight** | ___ kg | ___ kg | ___ kg |
| Waist | ___ cm | ___ cm | ___ cm |
| Hips | ___ cm | ___ cm | ___ cm |
| Chest | ___ cm | ___ cm | ___ cm |

> [!info] **Reading the Scale**
> - Daily scale fluctuates 1–2kg from water/food/hormones — trust averages.
> - Waist ↓ + weight same = **recomposition win**. That's ideal.
> - Target rate: **0.3–0.7 kg/week** on a cut.

---

## 📊 AUTO-PULLED WEEKLY STATS

> [!example]+ 📈 **This Week's Daily Logs**
> ```dataview
> TABLE WITHOUT ID
>   file.link AS "Day",
>   weight_kg AS "Wt",
>   calories_actual AS "Cal",
>   protein_actual AS "Prot",
>   steps AS "Steps",
>   sleep_hrs AS "Sleep",
>   overall_score AS "Score"
> FROM #daily-log
> WHERE date >= date(today) - dur(7 days)
> SORT date DESC
> ```

> [!abstract]+ 📉 **Weekly Averages**
> ```dataviewjs
> const pages = dv.pages('#daily-log').where(p => p.date >= dv.date('today').minus({days: 7}));
> if (pages.length === 0) { dv.paragraph("_No logs this week yet._"); }
> else {
>   const avg = (arr) => arr.length ? (arr.reduce((a,b)=>a+b,0)/arr.length).toFixed(1) : 'N/A';
>   const w = avg(pages.map(p => p.weight_kg).filter(v => v).array());
>   const c = avg(pages.map(p => p.calories_actual).filter(v => v).array());
>   const p = avg(pages.map(p => p.protein_actual).filter(v => v).array());
>   const s = avg(pages.map(p => p.steps).filter(v => v).array());
>   const sl = avg(pages.map(p => p.sleep_hrs).filter(v => v).array());
>   const tr = pages.where(x => x.workout_done == true).length;
>   dv.paragraph(`
> - ⚖️ Avg Weight: **${w} kg**
> - 🔥 Avg Calories: **${c}**
> - 🥩 Avg Protein: **${p} g**
> - 👟 Avg Steps: **${s}**
> - 😴 Avg Sleep: **${sl} h**
> - 🏋️ Workouts Done: **${tr} / 4**
> `);
> }
> ```

---

## 🏋️ DUMBBELL PROGRESSION AUDIT

### Did You Beat Last Week?

| Exercise | Last Wk | This Wk | ↑ ↓ → |
|---|---|---|---|
| Incline DB Press | | | |
| Flat DB Press | | | |
| Seated DB Shoulder Press | | | |
| Arnold Press | | | |
| Lateral Raises | | | |
| DB Tricep Extension | | | |
| Single Arm DB Row | | | |
| Hammer Curl | | | |
| DB Curl | | | |
| Romanian Deadlift | | | |
| Goblet Squat / Leg Press | | | |
| Calf Raises | | | |

> [!success] **Progressive Overload Law**
> Even **1 extra rep** at the same weight = progress. You must beat SOMETHING every week.

---

## 🗓️ WORKOUT COMPLIANCE

| Day | Planned | Done | Notes |
|---|---|---|---|
| Monday | Push | ☐ | |
| Tuesday | Pull | ☐ | |
| Wednesday | Legs | ☐ | |
| Thursday | Cardio | ☐ | |
| Friday | Upper | ☐ | |
| Saturday | Cardio | ☐ | |
| Sunday | Rest | — | |

**Workouts completed:** ___ / 4
**Cardio sessions:** ___ / 2

---

## ❤️ CARDIO & STEPS

| Day | Type | Duration | Steps |
|---|---|---|---|
| Mon | | | |
| Tue | | | |
| Wed | | | |
| Thu | | | |
| Fri | | | |
| Sat | | | |
| Sun | | | |

**Avg Daily Steps:** ___
**Total Cardio min:** ___

---

## 🍱 NUTRITION HONESTY CHECK

| Day | Cal | Prot | Water | On Target? |
|---|---|---|---|---|
| Mon | | | | ☐ |
| Tue | | | | ☐ |
| Wed | | | | ☐ |
| Thu | | | | ☐ |
| Fri | | | | ☐ |
| Sat | | | | ☐ |
| Sun | | | | ☐ |

**Diet Adherence:** ___% of days on target

> [!warning] **Brutally honest?** Any untracked bites, sneaky snacks, "forgotten" drinks? Write them down below:
>

---

## 😴 SLEEP DATA

| Day | Bedtime | Wake | Hrs | Quality /10 |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

---

## 💪 PERFORMANCE REPORT

**Energy (avg 1–10):** ___
**Gym performance:** ↑ Better / → Same / ↓ Worse

**🏆 Best Lift This Week:**
> Exercise: ___ | Weight: ___ kg | Reps: ___

**🪫 Weakest Area:**
>

**🔥 Muscle feeling most worked:**
>

---

## 📸 PROGRESS PHOTOS

- [ ] Front
- [ ] Side
- [ ] Back

Photo folder link:

---

## 🎖️ WEEKLY SCORECARD

| Category | Score /10 | Comment |
|---|---|---|
| 🍱 Diet | | |
| 🏋️ Training | | |
| ❤️ Cardio | | |
| 😴 Sleep | | |
| ⭐ **Overall** | | |

---

## 🧠 COUNCIL REFLECTION

### ✅ What went well?
>

### ❌ What didn't work?
>

### 🔍 Root cause of the misses:
>

### 🚀 Next week's adjustments:
>

### 💬 How are you feeling about progress?
>

---

## 🎯 NEXT WEEK GOALS

- [ ] Goal 1:
- [ ] Goal 2:
- [ ] Goal 3:
- [ ] Specific lift to push:
- [ ] Nutrition focus:

---

## 🔄 CALORIE ADJUSTMENT DECISION

> [!info] **The Formula**
> - Lost **>1 kg this week** → Too fast. Add +100–150 kcal.
> - Lost **0.3–0.7 kg** → Perfect. Hold calories.
> - Lost **<0.2 kg** for 3+ weeks → Drop 100–150 kcal OR add 30 min cardio.
> - **No change / gained** → Audit tracking. Something's off.

**Decision:** Keep / Increase / Decrease → **New target: ___ kcal**

---

[[🏯 Dashboard]] • [[💥 Workout Plan]] • [[Templates/📖 Daily Log Template]]

---

```
  「 WEEK SEALED 」  Next arc begins Monday.
```
