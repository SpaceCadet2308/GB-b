---
exercise:
weight_kg:
reps:
date: {{date:YYYY-MM-DD}}
body_weight:
notes:
tags: [pr, fitness]
---

# 🏆 PR ── [Exercise Name]

> **"When you break a PR, you break a version of yourself."**

| Detail | Value |
|---|---|
| 🏋️ Exercise | |
| 💪 Weight | ___ kg |
| 🔁 Reps | ___ |
| 📆 Date | {{date:YYYY-MM-DD}} |
| ⚖️ Body weight | ___ kg |
| 🔥 How it felt | |

## 🎬 Context

- **Session:** Push / Pull / Legs / Upper
- **Rep scheme before PR:** (e.g., had been stuck at 22.5kg × 8 for 3 weeks)
- **What changed:** (e.g., slept 9h, new pre-workout, better cue)

## 💭 Notes

>

---

## ⚙️ How to Use This Template

1. **Duplicate** this file when you hit a PR
2. **Rename** it like: `Incline DB Press PR 2024-11-15`
3. Put it in the `📁 PR Tracker/` folder
4. Fill in the frontmatter (`exercise:`, `weight_kg:`, `reps:`, `date:`)
5. Your [[🏯 Dashboard]] will auto-show it 🏆

> Only log your **all-time best** for each exercise. When you beat it, create a new file and the older one can be deleted (or archived in a subfolder).

[[🏯 Dashboard]]
