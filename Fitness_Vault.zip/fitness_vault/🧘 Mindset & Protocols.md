---
tags: [mindset, philosophy]
---

# 🧘 MINDSET & PROTOCOLS ── The Inner Domain

> [!quote] **"Throughout heaven and earth, I alone am the honored one."**
> ─ Gojo Satoru
>
> That's the energy you bring to every rep, every meal, every choice.

---

## 🗡️ THE FIVE LAWS OF THE HUNTER

### I. Consistency > Intensity
> A mediocre workout done beats a perfect workout skipped.
> Saitama did **100 push-ups, 100 sit-ups, 100 squats, 10km run** — *every single day.*
> Not occasionally. **Every. Single. Day.**

### II. The Mirror Lies at First
> Fat loss shows in the **tape** and **photos** before the mirror.
> Trust the data, not your daily reflection. Some days you'll look worse and be leaner.

### III. Track or Die
> If it's not logged, it didn't happen — and if it didn't happen, it can't be improved.
> **Cursed energy = calories.** You can't cast Domain Expansion without knowing your reserves.

### IV. Sleep is a Training Input
> Bad sleep ↑ ghrelin (hunger hormone) by **24%**.
> You literally get fatter from sleeping less. Gojo sleeps. So do you.

### V. Protect the Process
> Don't chase the scale. Chase the **inputs** — protein hit, steps hit, lifts done.
> If the inputs are right for 4+ weeks, the outputs **must** follow. Physics.

---

## 🩸 THE WARRIOR CODE

```
  1. I train even when I don't feel like it.
  2. I eat to fuel, not to cope.
  3. I walk when I could sit.
  4. I sleep when I could scroll.
  5. I log every rep, every meal, every win.
  6. I compete with yesterday's me — nobody else.
  7. I show up. Always.
```

---

## 🌀 WHEN YOU WANT TO QUIT

> [!fire] **The 10-Minute Rule**
> You don't have to train for an hour. Commit to **10 minutes.**
> Put on your shoes. Walk to the gym. Do the first set.
>
> 90% of the time, you'll finish the session. The other 10%, you at least got 10 minutes in.

> [!fire] **The Baki Method**
> When training feels impossible, remember: *somewhere, someone is training harder than you — and they're not as talented.*
> Your excuses are being out-worked right now.

> [!fire] **The Gojo Flex**
> You're not weak. You just haven't awakened yet.
> Awakening isn't a moment — it's 1000 small decisions in a row.

---

## 🎯 WHEN PROGRESS STALLS (3+ weeks no movement)

Run through this checklist honestly:

- [ ] Am I **actually** hitting protein every day (not "most days")?
- [ ] Am I tracking **liquids**? Oils? Sauces? Coffee add-ins?
- [ ] Are my **weekend calories** sabotaging my weekday deficit?
- [ ] Am I sleeping **7+ hours** consistently?
- [ ] Am I hitting **8k steps** daily, or just on gym days?
- [ ] Am I **progressing** weights/reps in the gym?
- [ ] Am I actually **stressed**? (cortisol holds water → fake "no progress")

If all 7 are green and the scale hasn't moved in 3 weeks → **drop 100–150 kcal OR add 30 min cardio**. Not both.

---

## 🪷 RECOVERY PROTOCOL — The Hidden Edge

Most people think recovery = "do nothing."
**Wrong.** Recovery is **active** and can be optimized.

| Lever | Action | Why |
|---|---|---|
| 😴 Sleep | 7–9h, same time ± 30 min | Primary recovery driver |
| 💧 Water | 3.5L+ daily | Transports nutrients, flushes metabolites |
| 🚶 Walks | 20 min post-dinner | Digestion + NEAT + blood flow |
| 🧘 Breathwork | Box breathing 5 min | Parasympathetic reset |
| 🥩 Protein | 30g per meal | Muscle protein synthesis spaced out |
| 🍌 Pre-bed carbs | Small (rice cakes, fruit) | Better sleep for some |
| 📵 No screens | 30 min before bed | Melatonin preserved |

---

## 🎭 THE TWO WOLVES INSIDE

> An old teacher once said: **Two wolves live in you.**
> One is weakness — the voice that says *"tomorrow, just this once, you deserve rest."*
> The other is the Shadow Monarch — the voice that says *"one more rep, one more walk, one more meal on target."*
>
> **Which one wins?**
>
> *The one you feed.*

---

## 🔥 DAILY AFFIRMATIONS (read before training)

- I am not here to be average. I am here to become unrecognizable.
- My body is a weapon. I maintain it with discipline.
- The work I do today is the physique I wear in 6 months.
- Pain is data. Discomfort is growth.
- I don't **need** motivation. I have **identity.**

---

## 🌑 THE LONG GAME

> **90 days from now**, you will either look exactly the same, or you will be transformed.
>
> The difference is not talent.
> The difference is not genetics.
> The difference is not your starting point.
>
> **The difference is: did you track, train, and sleep — consistently — for 90 days?**
>
> That's it. That's the whole secret.

---

[[🏯 Dashboard]] • [[💥 Workout Plan]] • [[Templates/📖 Daily Log Template]]

---

```
            「 THE SHADOW ARMY RISES 」
         Every day you train, it grows stronger.
```
